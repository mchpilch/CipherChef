import Classes.*;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class Main {
    public static void main(String[] args) throws UnsupportedAudioFileException, IOException, LineUnavailableException, NoSuchPaddingException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException {

        //ad.zadanie1
//        Monoalphabetic mono = new Monoalphabetic();
//        mono.setInput("Litwo Ojczyzno moja Ty jesteś");
//        mono.encrypt();
//        System.out.println(mono.getOutput());

        //ad.zadanie2
//        Playfair playfair = new Playfair();
//        playfair.setKey("JPWP");
//        playfair.displayMatrix();

        //ad.zadanie3
//        MorseCode morseCode = new MorseCode();
//        morseCode.soundMorseCode("... --- ... / .--- .--. .-- .--. /... --- ... ");

        //ad.zadanie4
//        AES aes = new AES("CBC");
//        aes.setInputString("Litwo ojczyzno moja");
//        aes.setKeyString("thisisa128bitkey");
//        aes.setIv("RKA2IpuGQlBJAez6276obQ==");
//        aes.encrypt();
//        System.out.println(aes.getOutputString());
    }
}
